<?php

class Creativestyle_AffiliNet_Block_Adminhtml_Datafeed_Preview extends Mage_Adminhtml_Block_Template {

}
