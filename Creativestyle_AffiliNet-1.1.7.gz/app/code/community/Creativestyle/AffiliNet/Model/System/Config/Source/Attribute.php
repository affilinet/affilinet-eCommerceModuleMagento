<?php

class Creativestyle_AffiliNet_Model_System_Config_Source_Attribute
{
    public $options = array();


}